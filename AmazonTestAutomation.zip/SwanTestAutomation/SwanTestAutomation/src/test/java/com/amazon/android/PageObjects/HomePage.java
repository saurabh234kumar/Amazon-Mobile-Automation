package com.amazon.android.PageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.amazon.apps.Locators.AndroidLocators;
import com.amazon.apps.utils.AndroidUtils;

import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



public class HomePage {
	
	AndroidUtils utils;
	
	
	@FindBy(id=AndroidLocators.HP_SearchField_ID)
	WebElement HP_SearchField ;
	
	@FindBy(xpath=AndroidLocators.DealCurrency_XPath)
	WebElement DealCurrency; 
	
	@FindBy(id=AndroidLocators.HP_SearchSujjestion_ID)
	WebElement HP_SearchSujjestion;
	
	AppiumDriver<MobileElement> driver;
	private static Logger testLogger = LogManager.getLogger(Logger.class.getName());
	
	
	public HomePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	/*-------------> The code below belongs to Test Methods<---------------------  */	

	public boolean navigateToTodaysDeal(){
		boolean flag=true;
		try{			
			if(HP_SearchField.isDisplayed()==true){
				testLogger.info("Fetching Search field: "+HP_SearchField.getText());
				WebDriverWait wait1 = new WebDriverWait(driver,50);
				wait1.until(ExpectedConditions.elementToBeClickable(By.id("com.amazon.mShop.android.shopping:id/rs_search_src_text")));
				HP_SearchField.click();
				WebDriverWait wait2 = new WebDriverWait(driver,50);
				wait2.until(ExpectedConditions.elementToBeClickable(By.id("com.amazon.mShop.android.shopping:id/rs_search_src_text")));
				HP_SearchField.sendKeys("apple");
				HP_SearchSujjestion.click();
				testLogger.info("Fetching items Price currency : "+DealCurrency.getText());
		}
		}catch(Exception exp)
		{
			System.out.println("cause is : "+exp.getCause());
			System.out.println("Message is : "+exp.getMessage());
			exp.printStackTrace();
		}
		return flag;	
		}
	

	
	
}
