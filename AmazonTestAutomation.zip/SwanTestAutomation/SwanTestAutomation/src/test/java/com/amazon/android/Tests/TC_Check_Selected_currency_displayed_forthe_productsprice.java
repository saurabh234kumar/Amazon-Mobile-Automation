package com.amazon.android.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.amazon.android.PageObjects.HomePage;
import com.amazon.android.PageObjects.MenuPage;
import com.amazon.android.PageObjects.SignInPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class TC_Check_Selected_currency_displayed_forthe_productsprice extends BaseClass {
	
	SignInPage confirm;
	MenuPage menu;
	HomePage home;

	@Test(alwaysRun=true, priority=1)
	public void TC_Navigate_To_CurrencyChange(ITestContext context){
	
		System.out.println("Test Started TC_Navigate_To_CurrencyChange");
		context.setAttribute("description","Currency Change from USD to AED");
		MenuPage accessTestMethod = new MenuPage(driver); 
		Assert.assertTrue(accessTestMethod.navigateToCurrencyChange());
		System.out.println("Completed Test TC_Navigate_To_CurrencyChange");
	}
	

	@Test(alwaysRun=true, priority=2)
	public void TC_Verify_Product_CurrencyPrice(ITestContext context){
	
		System.out.println("Test Started TC_Verify_Product_CurrencyPrice");
		context.setAttribute("description","Currency verification of product pricing");
		HomePage accessTestMethod = new HomePage(driver); 
		Assert.assertTrue(accessTestMethod.navigateToTodaysDeal());
		System.out.println("Completed Test TC_Verify_Product_CurrencyPrice");
	}

}
