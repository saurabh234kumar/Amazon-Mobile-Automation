package com.amazon.android.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.amazon.android.PageObjects.MenuPage;
import com.amazon.android.PageObjects.SignInPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class TC_Checktotal_results_category_SmartHome_Televisions extends BaseClass {
	
	SignInPage confirm;
	MenuPage menu;

	@Test(alwaysRun=true, priority=1)
	public void TC_Naviagte_To_ShopBtDept(ITestContext context){
	
		System.out.println("Test Started TC_Naviagte_To_ShopBtDept");
		context.setAttribute("description","Confirm SignIn page");
		MenuPage accessTestMethod = new MenuPage(driver); 
		Assert.assertTrue(accessTestMethod.navigateToShopByDepartment());
		System.out.println("Completed Test TC_Naviagte_To_ShopBtDept");
	}
}
