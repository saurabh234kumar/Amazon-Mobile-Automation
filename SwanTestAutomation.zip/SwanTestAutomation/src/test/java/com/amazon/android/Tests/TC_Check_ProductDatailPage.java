package com.amazon.android.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.amazon.android.PageObjects.HomePage;
import com.amazon.android.PageObjects.MenuPage;
import com.amazon.android.PageObjects.PDP;
import com.amazon.android.PageObjects.SignInPage;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class TC_Check_ProductDatailPage extends BaseClass {
	
	SignInPage confirm;
	MenuPage menu;
	HomePage home;
	PDP pdp;

	@Test(alwaysRun=true, priority=1)
	public void TC_Navigate_To_HomePage(ITestContext context){
	
		System.out.println("Test Started Navigate_To_HomePage");
		context.setAttribute("description","Navigate to Home Page");
		MenuPage accessTestMethod = new MenuPage(driver); 
		Assert.assertTrue(accessTestMethod.skipSignIn());
		System.out.println("Completed Test Navigate_To_HomePage");
	}
	
	@Test(alwaysRun=true, priority=2)
	public void TC_Verify_Product_CurrencyPrice(ITestContext context){
	
		System.out.println("Test Started TC_Verify_Product_CurrencyPrice");
		context.setAttribute("description","Currency verification of product pricing");
		HomePage accessTestMethod = new HomePage(driver); 
		Assert.assertTrue(accessTestMethod.navigateToTodaysDeal());
		System.out.println("Completed Test TC_Verify_Product_CurrencyPrice");
	}

	@Test(alwaysRun=true, priority=3)
	public void TC_Verify_ProductDetailPage(ITestContext context){
	
		System.out.println("Test Started TC_Verify_ProductDetailPage");
		context.setAttribute("description","Product Detail Page verification");
		PDP accessTestMethod = new PDP(driver); 
		Assert.assertTrue(accessTestMethod.navigateToPDP());
		System.out.println("Completed Test TC_Verify_ProductDetailPage");
	}

}
